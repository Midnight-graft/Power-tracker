# Power Tracker (Flutter, Android)

Offline prepaid electricity tracker: recharges, meter readings, days-left estimate, outage log.

## Setup
1. `flutter create --platforms=android power_tracker`
2. Replace its `pubspec.yaml` and `lib/` folder with the ones here, then `flutter pub get`.
3. In `android/app/build.gradle(.kts)` (needed by flutter_local_notifications):
   - inside `android { compileOptions { ... } }` add `isCoreLibraryDesugaringEnabled = true`
     (Groovy: `coreLibraryDesugaringEnabled true`)
   - add dependency: `coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")`
4. In `android/app/src/main/AndroidManifest.xml`, above `<application>`:
   `<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>`
   `<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>`
   and inside `<application>`:
   `<receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver"/>`
   `<receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver"><intent-filter><action android:name="android.intent.action.BOOT_COMPLETED"/></intent-filter></receiver>`
5. `flutter run` on a phone.

## Using it
Log a reading, recharge when you buy, log another reading a day later. The estimate needs two readings.
Log the reading AFTER entering a recharge so units are not double counted.
