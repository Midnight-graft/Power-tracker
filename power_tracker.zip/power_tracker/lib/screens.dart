import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'calc.dart';
import 'db.dart';
import 'notifications.dart';

final _dfmt = DateFormat('d MMM, HH:mm');
String fmtDur(Duration d) => '${d.inHours}h ${d.inMinutes % 60}m';
String _n(double v, [int dp = 1]) => v.toStringAsFixed(dp);

/// Reloads [load] whenever any data changes.
mixin AutoReload<T extends StatefulWidget> on State<T> {
  Future<void> load();
  @override
  void initState() {
    super.initState();
    dataChanged.addListener(_r);
    load();
  }
  void _r() => load();
  @override
  void dispose() {
    dataChanged.removeListener(_r);
    super.dispose();
  }
}

// ---------------------------------------------------------------- shell
class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _i = 0;
  static const _pages = [HomeScreen(), InsightsScreen(), OutagesScreen(), SettingsScreen()];
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(child: _pages[_i]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _i,
          onDestinationSelected: (v) => setState(() => _i = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.bolt), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Insights'),
            NavigationDestination(icon: Icon(Icons.power_off), label: 'Outages'),
            NavigationDestination(icon: Icon(Icons.settings), label: 'Settings'),
          ],
        ),
      );
}

// ---------------------------------------------------------------- entry sheet
Future<void> _entrySheet(
  BuildContext context, {
  required String title,
  required List<String> labels,
  required Future<void> Function(List<double> v, DateTime date) onSave,
}) {
  final ctrls = [for (final _ in labels) TextEditingController()];
  var date = DateTime.now();
  return showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) => Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, 20 + MediaQuery.of(ctx).viewInsets.bottom),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(title, style: Theme.of(ctx).textTheme.titleLarge),
          const SizedBox(height: 12),
          for (var i = 0; i < labels.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: TextField(
                controller: ctrls[i],
                autofocus: i == 0,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(labelText: labels[i], border: const OutlineInputBorder()),
              ),
            ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.event),
            title: Text(DateFormat('EEE d MMM yyyy').format(date)),
            trailing: const Text('Change'),
            onTap: () async {
              final p = await showDatePicker(
                  context: ctx, initialDate: date, firstDate: DateTime(2020), lastDate: DateTime.now());
              if (p != null) {
                final n = DateTime.now();
                setS(() => date = DateTime(p.year, p.month, p.day, n.hour, n.minute));
              }
            },
          ),
          FilledButton(
            onPressed: () async {
              final vals = ctrls.map((c) => double.tryParse(c.text.trim().replaceAll(',', '.'))).toList();
              if (vals.any((v) => v == null || v < 0) || vals.first == 0) {
                ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content: Text('Enter valid numbers')));
                return;
              }
              await onSave(vals.cast<double>(), date);
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: const Text('Save'),
          ),
        ]),
      ),
    ),
  );
}

Future<void> showRechargeSheet(BuildContext c) => _entrySheet(c,
    title: 'Add recharge',
    labels: ['Amount (GHS)', 'Units bought (kWh)'],
    onSave: (v, d) => Repo.addRecharge(Recharge(date: d, amountGhs: v[0], unitsKwh: v[1])));

Future<void> showReadingSheet(BuildContext c) => _entrySheet(c,
    title: 'Log meter reading',
    labels: ['Units on meter now (kWh)'],
    onSave: (v, d) => Repo.addReading(Reading(date: d, unitsRemaining: v[0])));

// ---------------------------------------------------------------- home
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeState();
}

class _HomeState extends State<HomeScreen> with AutoReload {
  Estimate? _e;
  double _threshold = 3, _costPerKwh = 2;
  bool _loaded = false;

  @override
  Future<void> load() async {
    final rd = await Repo.readings();
    final rc = await Repo.recharges();
    final th = double.tryParse(await Repo.getSetting('threshold') ?? '') ?? 3;
    var cost = double.tryParse(await Repo.getSetting('tariff') ?? '') ?? 2.0;
    final recent = rc.reversed.take(5).toList();
    final u = recent.fold<double>(0, (s, r) => s + r.unitsKwh);
    if (u > 0) cost = recent.fold<double>(0, (s, r) => s + r.amountGhs) / u;
    final e = estimate(rd, rc, DateTime.now());
    if (!mounted) return;
    setState(() {
      _e = e;
      _threshold = th;
      _costPerKwh = cost;
      _loaded = true;
    });
    if (e?.daysLeft != null && e!.daysLeft! < th) _alertOncePerDay(e.daysLeft!);
  }

  Future<void> _alertOncePerDay(double days) async {
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    if (await Repo.getSetting('last_alert') == today) return;
    await Repo.setSetting('last_alert', today);
    await Notifier.lowCredit(days);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final e = _e;
    final low = e?.daysLeft != null && e!.daysLeft! < _threshold;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Power Tracker', style: Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height: 12),
      Card(
        color: low ? cs.errorContainer : cs.primaryContainer,
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: !_loaded
              ? const Center(child: CircularProgressIndicator())
              : e == null
                  ? const Text('No readings yet.\nLog what your meter shows now to get started.',
                      style: TextStyle(fontSize: 18))
                  : Column(children: [
                      Text(e.daysLeft == null ? '--' : _n(e.daysLeft!),
                          style: const TextStyle(fontSize: 64, fontWeight: FontWeight.bold)),
                      const Text('days left (estimate)'),
                      const SizedBox(height: 12),
                      Text('${_n(e.balanceNow)} kWh on meter now',
                          style: Theme.of(context).textTheme.titleMedium),
                      if (e.dailyUse != null)
                        Text('${_n(e.dailyUse!, 2)} kWh/day  |  about GHS ${_n(e.dailyUse! * _costPerKwh)}/day')
                      else
                        const Text('Log another reading after a day or so to get a days-left estimate.',
                            textAlign: TextAlign.center),
                    ]),
        ),
      ),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(
            child: FilledButton.icon(
                onPressed: () => showRechargeSheet(context),
                icon: const Icon(Icons.add_card),
                label: const Text('Add recharge'))),
        const SizedBox(width: 12),
        Expanded(
            child: FilledButton.tonalIcon(
                onPressed: () => showReadingSheet(context),
                icon: const Icon(Icons.speed),
                label: const Text('Log reading'))),
      ]),
      const SizedBox(height: 16),
      const Text('Tip: log a reading right after you recharge, so the estimate stays accurate.',
          style: TextStyle(fontSize: 12)),
    ]);
  }
}

// ---------------------------------------------------------------- insights
class InsightsScreen extends StatefulWidget {
  const InsightsScreen({super.key});
  @override
  State<InsightsScreen> createState() => _InsightsState();
}

class _InsightsState extends State<InsightsScreen> with AutoReload {
  List<Recharge> _rc = [];
  List<Reading> _rd = [];
  bool _weekly = true;

  @override
  Future<void> load() async {
    final rc = await Repo.recharges();
    final rd = await Repo.readings();
    if (mounted) setState(() { _rc = rc; _rd = rd; });
  }

  List<MapEntry<String, double>> _buckets() {
    final now = DateTime.now();
    final out = <MapEntry<String, double>>[];
    if (_weekly) {
      final thisWeek = DateTime(now.year, now.month, now.day).subtract(Duration(days: now.weekday - 1));
      for (var i = 7; i >= 0; i--) {
        final s = thisWeek.subtract(Duration(days: 7 * i));
        final e = s.add(const Duration(days: 7));
        final sum = _rc.where((r) => !r.date.isBefore(s) && r.date.isBefore(e)).fold<double>(0, (a, r) => a + r.amountGhs);
        out.add(MapEntry(DateFormat('d/M').format(s), sum));
      }
    } else {
      for (var i = 5; i >= 0; i--) {
        final s = DateTime(now.year, now.month - i);
        final e = DateTime(now.year, now.month - i + 1);
        final sum = _rc.where((r) => !r.date.isBefore(s) && r.date.isBefore(e)).fold<double>(0, (a, r) => a + r.amountGhs);
        out.add(MapEntry(DateFormat('MMM').format(s), sum));
      }
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    final est = estimate(_rd, _rc, DateTime.now());
    final b = _buckets();
    final maxV = b.fold<double>(0, (m, e) => e.value > m ? e.value : m);
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Insights', style: Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height: 8),
      SegmentedButton<bool>(
        segments: const [ButtonSegment(value: true, label: Text('Weekly')), ButtonSegment(value: false, label: Text('Monthly'))],
        selected: {_weekly},
        onSelectionChanged: (s) => setState(() => _weekly = s.first),
      ),
      const SizedBox(height: 16),
      const Text('Spend (GHS)'),
      const SizedBox(height: 8),
      SizedBox(
        height: 170,
        child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          for (final e in b)
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3),
                child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                  Text(e.value == 0 ? '' : _n(e.value, 0), style: const TextStyle(fontSize: 10)),
                  Container(
                    height: maxV == 0 ? 2 : (e.value / maxV * 110).clamp(2, 110).toDouble(),
                    decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primary, borderRadius: BorderRadius.circular(4)),
                  ),
                  const SizedBox(height: 4),
                  Text(e.key, style: const TextStyle(fontSize: 10)),
                ]),
              ),
            ),
        ]),
      ),
      const SizedBox(height: 12),
      Card(
        child: ListTile(
          leading: const Icon(Icons.show_chart),
          title: Text(est?.dailyUse == null ? 'Average daily use: not enough data yet' : 'Average daily use: ${_n(est!.dailyUse!, 2)} kWh'),
          subtitle: const Text('Based on the last 14 days of readings'),
        ),
      ),
      const SizedBox(height: 8),
      Text('Recharges', style: Theme.of(context).textTheme.titleMedium),
      if (_rc.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('None yet.')),
      for (final r in _rc.reversed)
        ListTile(
          dense: true,
          title: Text('GHS ${_n(r.amountGhs, 2)}  ->  ${_n(r.unitsKwh)} kWh'),
          subtitle: Text(_dfmt.format(r.date)),
          trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => Repo.deleteRecharge(r.id!)),
        ),
      const SizedBox(height: 8),
      Text('Readings', style: Theme.of(context).textTheme.titleMedium),
      if (_rd.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('None yet.')),
      for (final r in _rd.reversed)
        ListTile(
          dense: true,
          title: Text('${_n(r.unitsRemaining)} kWh'),
          subtitle: Text(_dfmt.format(r.date)),
          trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => Repo.deleteReading(r.id!)),
        ),
    ]);
  }
}

// ---------------------------------------------------------------- outages
class OutagesScreen extends StatefulWidget {
  const OutagesScreen({super.key});
  @override
  State<OutagesScreen> createState() => _OutagesState();
}

class _OutagesState extends State<OutagesScreen> with AutoReload {
  List<Outage> _o = [];

  @override
  Future<void> load() async {
    final o = await Repo.outages();
    if (mounted) setState(() => _o = o);
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final ongoing = _o.where((o) => o.end == null).toList();
    final month = DateTime(now.year, now.month);
    final total = _o.where((o) => !o.start.isBefore(month)).fold<Duration>(Duration.zero, (s, o) => s + o.duration(now));
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Outages', style: Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height: 12),
      SizedBox(
        height: 72,
        child: ongoing.isEmpty
            ? FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: Theme.of(context).colorScheme.error),
                onPressed: Repo.startOutage,
                icon: const Icon(Icons.power_off),
                label: const Text('Power just went off', style: TextStyle(fontSize: 18)))
            : FilledButton.icon(
                onPressed: () => Repo.endOutage(ongoing.first.id!),
                icon: const Icon(Icons.power),
                label: Text('Power is back (off since ${DateFormat('HH:mm').format(ongoing.first.start)})',
                    style: const TextStyle(fontSize: 16))),
      ),
      const SizedBox(height: 12),
      Card(child: ListTile(leading: const Icon(Icons.timer_outlined), title: Text('This month: ${fmtDur(total)} without power'))),
      if (_o.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('No outages logged. Tap the button when the lights go off.')),
      for (final o in _o)
        ListTile(
          dense: true,
          title: Text(o.end == null ? 'Ongoing: ${fmtDur(o.duration(now))}' : fmtDur(o.duration())),
          subtitle: Text(_dfmt.format(o.start)),
          trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => Repo.deleteOutage(o.id!)),
        ),
    ]);
  }
}

// ---------------------------------------------------------------- settings
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsState();
}

class _SettingsState extends State<SettingsScreen> {
  final _th = TextEditingController(), _tf = TextEditingController();
  bool _reminder = false;

  @override
  void initState() {
    super.initState();
    () async {
      _th.text = await Repo.getSetting('threshold') ?? '3';
      _tf.text = await Repo.getSetting('tariff') ?? '2.0';
      _reminder = (await Repo.getSetting('reminder')) == '1';
      if (mounted) setState(() {});
    }();
  }

  Future<void> _export() async {
    final rc = await Repo.recharges(), rd = await Repo.readings(), ou = await Repo.outages();
    final b = StringBuffer('type,date,value1,value2\n');
    final f = DateFormat('yyyy-MM-dd HH:mm');
    for (final r in rc) { b.writeln('recharge,${f.format(r.date)},${r.amountGhs},${r.unitsKwh}'); }
    for (final r in rd) { b.writeln('reading,${f.format(r.date)},${r.unitsRemaining},'); }
    for (final o in ou) { b.writeln('outage,${f.format(o.start)},${o.end == null ? '' : f.format(o.end!)},${o.duration().inMinutes}'); }
    await Clipboard.setData(ClipboardData(text: b.toString()));
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('CSV copied. Paste it into a note or sheet.')));
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
        Text('Settings', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 16),
        TextField(
          controller: _th,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'Low-credit alert (days left)', border: OutlineInputBorder()),
          onChanged: (v) { if (double.tryParse(v) != null) { Repo.setSetting('threshold', v); notifyChanged(); } },
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _tf,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(
              labelText: 'Tariff estimate (GHS per kWh)',
              helperText: 'Used for cost/day until you log a recharge',
              border: OutlineInputBorder()),
          onChanged: (v) { if (double.tryParse(v) != null) { Repo.setSetting('tariff', v); notifyChanged(); } },
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Daily reminder to log a reading'),
          value: _reminder,
          onChanged: (v) async {
            setState(() => _reminder = v);
            await Repo.setSetting('reminder', v ? '1' : '0');
            await Notifier.setDailyReminder(v);
          },
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(onPressed: _export, icon: const Icon(Icons.copy), label: const Text('Export data as CSV (copy)')),
      ]);
}
