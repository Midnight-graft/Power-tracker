import 'db.dart';

class Estimate {
  final double balanceNow; // estimated kWh on the meter right now
  final double? dailyUse; // kWh/day, null until 2 usable readings exist
  final double? daysLeft;
  Estimate(this.balanceNow, this.dailyUse, this.daysLeft);
}

/// [readings] must be sorted oldest to newest.
/// Daily use = (earlier reading + units recharged in between - later reading) / days,
/// pooled over reading pairs from the last 14 days.
Estimate? estimate(List<Reading> readings, List<Recharge> recharges, DateTime now) {
  if (readings.isEmpty) return null;
  final cutoff = now.subtract(const Duration(days: 14));
  double used = 0, days = 0;

  for (var i = 1; i < readings.length; i++) {
    final a = readings[i - 1], b = readings[i];
    if (b.date.isBefore(cutoff)) continue;
    final d = b.date.difference(a.date).inMinutes / 1440.0;
    if (d < 1 / 24) continue; // ignore pairs less than an hour apart
    final added = recharges
        .where((r) => r.date.isAfter(a.date) && !r.date.isAfter(b.date))
        .fold<double>(0, (s, r) => s + r.unitsKwh);
    final c = a.unitsRemaining + added - b.unitsRemaining;
    if (c < 0) continue; // typo or meter swap, skip the pair
    used += c;
    days += d;
  }

  final latest = readings.last;
  final dailyUse = days > 0 && used > 0 ? used / days : null;
  final addedSince = recharges
      .where((r) => r.date.isAfter(latest.date))
      .fold<double>(0, (s, r) => s + r.unitsKwh);
  final elapsed = now.difference(latest.date).inMinutes / 1440.0;
  var balance = latest.unitsRemaining + addedSince - (dailyUse ?? 0) * elapsed;
  if (balance < 0) balance = 0;
  return Estimate(balance, dailyUse, dailyUse == null ? null : balance / dailyUse);
}
