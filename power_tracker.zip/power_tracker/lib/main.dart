import 'package:flutter/material.dart';
import 'notifications.dart';
import 'screens.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Notifier.init();
  runApp(const PowerApp());
}

class PowerApp extends StatelessWidget {
  const PowerApp({super.key});
  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFFF59E0B);
    return MaterialApp(
      title: 'Power Tracker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: seed, useMaterial3: true),
      darkTheme: ThemeData(colorSchemeSeed: seed, brightness: Brightness.dark, useMaterial3: true),
      home: const Shell(),
    );
  }
}
