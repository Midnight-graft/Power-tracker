import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class Notifier {
  static final _p = FlutterLocalNotificationsPlugin();
  static const _details = NotificationDetails(
    android: AndroidNotificationDetails('power_channel', 'Power alerts',
        importance: Importance.high, priority: Priority.high),
  );

  static Future<void> init() async {
    await _p.initialize(const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher')));
    await _p
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  static Future<void> lowCredit(double days) => _p.show(
      1, 'Power running low',
      'About ${days.toStringAsFixed(1)} days left. Time to recharge.', _details);

  static Future<void> setDailyReminder(bool on) async {
    if (on) {
      await _p.periodicallyShow(2, 'Log your meter', 'Takes 10 seconds. Log today\'s reading.',
          RepeatInterval.daily, _details,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle);
    } else {
      await _p.cancel(2);
    }
  }
}
