import 'package:flutter/foundation.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

/// Bump to tell every screen to reload.
final dataChanged = ValueNotifier<int>(0);
void notifyChanged() => dataChanged.value++;

DateTime _dt(Object? v) => DateTime.fromMillisecondsSinceEpoch(v as int);

class Recharge {
  final int? id;
  final DateTime date;
  final double amountGhs, unitsKwh;
  Recharge({this.id, required this.date, required this.amountGhs, required this.unitsKwh});
  factory Recharge.fromMap(Map<String, Object?> m) => Recharge(
      id: m['id'] as int,
      date: _dt(m['date']),
      amountGhs: (m['amount_ghs'] as num).toDouble(),
      unitsKwh: (m['units_kwh'] as num).toDouble());
  Map<String, Object?> toMap() => {
        'date': date.millisecondsSinceEpoch,
        'amount_ghs': amountGhs,
        'units_kwh': unitsKwh
      };
}

class Reading {
  final int? id;
  final DateTime date;
  final double unitsRemaining;
  Reading({this.id, required this.date, required this.unitsRemaining});
  factory Reading.fromMap(Map<String, Object?> m) => Reading(
      id: m['id'] as int,
      date: _dt(m['date']),
      unitsRemaining: (m['units_remaining'] as num).toDouble());
  Map<String, Object?> toMap() =>
      {'date': date.millisecondsSinceEpoch, 'units_remaining': unitsRemaining};
}

class Outage {
  final int? id;
  final DateTime start;
  final DateTime? end;
  final String note;
  Outage({this.id, required this.start, this.end, this.note = ''});
  factory Outage.fromMap(Map<String, Object?> m) => Outage(
      id: m['id'] as int,
      start: _dt(m['start_ts']),
      end: m['end_ts'] == null ? null : _dt(m['end_ts']),
      note: (m['note'] as String?) ?? '');
  Duration duration([DateTime? now]) => (end ?? now ?? DateTime.now()).difference(start);
}

class Repo {
  static Database? _db;

  static Future<Database> get db async {
    if (_db != null) return _db!;
    final path = join(await getDatabasesPath(), 'power_tracker.db');
    _db = await openDatabase(path, version: 1, onCreate: (d, v) async {
      await d.execute(
          'CREATE TABLE recharges(id INTEGER PRIMARY KEY AUTOINCREMENT, date INTEGER NOT NULL, amount_ghs REAL NOT NULL, units_kwh REAL NOT NULL)');
      await d.execute(
          'CREATE TABLE readings(id INTEGER PRIMARY KEY AUTOINCREMENT, date INTEGER NOT NULL, units_remaining REAL NOT NULL)');
      await d.execute(
          'CREATE TABLE outages(id INTEGER PRIMARY KEY AUTOINCREMENT, start_ts INTEGER NOT NULL, end_ts INTEGER, note TEXT)');
      await d.execute('CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)');
    });
    return _db!;
  }

  // Recharges
  static Future<List<Recharge>> recharges() async =>
      (await (await db).query('recharges', orderBy: 'date ASC')).map(Recharge.fromMap).toList();
  static Future<void> addRecharge(Recharge r) async {
    await (await db).insert('recharges', r.toMap());
    notifyChanged();
  }
  static Future<void> deleteRecharge(int id) async {
    await (await db).delete('recharges', where: 'id=?', whereArgs: [id]);
    notifyChanged();
  }

  // Readings
  static Future<List<Reading>> readings() async =>
      (await (await db).query('readings', orderBy: 'date ASC')).map(Reading.fromMap).toList();
  static Future<void> addReading(Reading r) async {
    await (await db).insert('readings', r.toMap());
    notifyChanged();
  }
  static Future<void> deleteReading(int id) async {
    await (await db).delete('readings', where: 'id=?', whereArgs: [id]);
    notifyChanged();
  }

  // Outages
  static Future<List<Outage>> outages() async =>
      (await (await db).query('outages', orderBy: 'start_ts DESC')).map(Outage.fromMap).toList();
  static Future<void> startOutage() async {
    await (await db).insert('outages', {'start_ts': DateTime.now().millisecondsSinceEpoch, 'note': ''});
    notifyChanged();
  }
  static Future<void> endOutage(int id) async {
    await (await db).update('outages', {'end_ts': DateTime.now().millisecondsSinceEpoch},
        where: 'id=?', whereArgs: [id]);
    notifyChanged();
  }
  static Future<void> deleteOutage(int id) async {
    await (await db).delete('outages', where: 'id=?', whereArgs: [id]);
    notifyChanged();
  }

  // Settings
  static Future<String?> getSetting(String key) async {
    final r = await (await db).query('settings', where: 'key=?', whereArgs: [key]);
    return r.isEmpty ? null : r.first['value'] as String?;
  }
  static Future<void> setSetting(String key, String value) async {
    await (await db).insert('settings', {'key': key, 'value': value},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }
}
